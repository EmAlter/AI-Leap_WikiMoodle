# Contratti - Gestire le Attività

L'utente è loggato su Moodle come amministratore (progettista) e ha tutti i permessi.

---

Nei contratti è stato definito che una raccoltà attività rappresenta un contenitore di elementi attività e ognuno di essi e costituito da domande e risposte.
Per esempio, considerando l

## Creare una raccolta attività
In Moodle una raccolta attività è definita come "Deposito delle domande". Esistono vari livelli più o meno generali, ma nel contesto del caso d'uso, stiamo parlando di una raccolta attività a livello di sistema accessibile ovunque.
I passi per creare una nuova raccolta attività sono:
1. Accedere alla Home page di Moodle
2. Cliccare su "Deposito delle domande" nel menù centrale
3. Nel menù a tendina scegliere "Categorie", una volta caricata la pagina cliccare su "Aggiungi categoria" e inserire:
   - Nome categoria --> es. "Raccolta Attività"
   - Categoria genitore --> Default per Sistema
   - Informazioni categoria --> es. "Raccolta attività contenente tutte le attività dei test"
4. Salvare la nuova categoria

## Selezionare una raccolta attività
Per selezionare una raccolta attività esistente, i passi sono:
1. Accedere alla Home page di Moodle
2. Cliccare su "Deposito delle domande" nel menù centrale
3. Nel menù a tendina scegliere "Categorie", una volta caricata la pagina cliccare sulla categoria desiderata, in questo caso "Raccolta Attività" (in base al nome scelto in precedenza)

## Creare una nuova attività
Per creare una nuova attività all'interno di una raccolta attività, ci sono due possibili strade:
* Si è all'interno di una raccolta attività esistente:
    1. Cliccare su "Crea nuova domanda"
    2. Nel menù che si aprirà scegliere la tipologia della domanda e cliccare su "Aggiungi"
    3. Compilare i campi:
       - Nome della domanda --> es. "Attività 1"
       - Testo della domanda --> es. "Descrizione dell'attività 1"
* Si è all'interno di un modulo Quiz:
    1. Cliccare nel menù centrale "Domande"
    2. Cliccare in alto a destra il pulsante "Aggiungi" e dal menù a tendina scegliere "+ una domanda"
    3. Prima di modificare il nome e il testo della domanda è importante selezionare nel campo "Categoria" la raccoltà attività di sistema già esistente, se non selezionata di default, in modo da salvare al suo interno la nuova domanda

## Selezionare un'attività esistente
Dalla raccolta attività è possibile selezionare un'attività creata precedentemente e modificarne eventualmente il nome o il testo della domanda. 
I passi sono:
1. Nella raccoltà attività scorrere in basso la lista delle attività esistenti
2. Cliccare sul pulsante "Modifica" nella colonna "Azioni" e scegliere "Modifica domanda" dal menù a tendina

## Eliminare un'attività esistente
Dalla raccolta attività è possibile eliminare un'attività creata precedentemente.
I passi sono:
1. Nella raccoltà attività scorrere in basso la lista delle attività esistenti
2. Cliccare sul pulsante "Modifica" nella colonna "Azioni" e scegliere "Elimina" dal menù a tendina

## Definire una domanda 